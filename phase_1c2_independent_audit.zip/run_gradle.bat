@echo off
set "JAVA_HOME=C:\Users\Admin\.gradle\jdks\eclipse_adoptium-21-amd64-windows.2"
set "PATH=%JAVA_HOME%\bin;%PATH%"
cd /d "C:\Users\Admin\.gemini\antigravity\scratch\ModForQualitySupport"
call gradlew.bat %*
